//: Playground - noun: a place where people can play

import UIKit

struct Game {
    var turnNumber: Int
    var playersTurn: Bool
    var cimonsTurn: Bool
    var cimonsSequence = [String]()
    func cimonsTurn (cimonsSequence: cimonsSequence) -> Array<Int> {                                    //operations that need to happen during cimon's turn
        cimonsSequence.append(numberToColorConversion(arc4random_uniform(4)))                           //generate a random int from 0 to 3
        cimonGame.cimonsTurn = false                                                                    //then use the numberToColorConversion function
        cimonGame.playersTurn = true                                                                    //finally append the color to cimonsSeqence
    }
    func playersTurn() -> Array<String> {
        var playersSequence = Array<String>()
        for counter in cimonGame.turnNumber {
            playersSequence[counter].append(//get the color from the UI)
        }
        return playersSequence
    }
}
func numberToColorConversion(generatedNumber: Int) -> String {
    switch generatedNumber {
    case 0:
        return "Green"
    case 1:
        return "Red"
    case 2:
        return "Yellow"
    case 3:
        return "Blue"
    }
}

var cimonGame = Game(turnNumber: 0, playersTurn: false, cimonsTurn: true, cimonsSequence: [String])
