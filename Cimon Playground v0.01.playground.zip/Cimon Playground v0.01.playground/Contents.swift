//The structure for Cimon

import UIKit

struct Game {
    var turnNumber: Int
}

func cimonGame () {
    var playersTurn = false
    var cimonsTurn = true
    var cimonsSequence = [Colors]
    var isGameOver = false
    while (cimonsTurn == true){
        cimonsSequence = cimonsTurnsActions(cimonsSequence)
        cimonsTurn = false
    }
    while (playersTurn == true){
        var playersSequenceThisTurn = playersTurnsActions()
        isGameOver = doTheSequencesMatch(playersSequenceThisTurn, cimonsSequence)
        playersSequenceThisTurn = playersSequenceThisTurn.removeAll()
        playersTurn = false
    }
}

func cimonsTurnsActions (cimonsSequence : Array) - > Array{
    cimonsSequence += 1 //random enum later
    //display cimonsSequence on screen
    return cimonsSequnce
}

func playersTurnsActions () -> Array{
    //get sequnce from the player
    return playersSequenceThisTurn
}

func doTheSequencesMatch (playersSequence : Array, cimonsSequence : Array) -> Bool {
    let numberOfElementsInSequence = cimonsSequence.length()
    var counter = 0
    while (counter <= numberOfElementsInSequence) {
        if playersSequence[counter] == cimonsSequence[counter] {
            counter += 1
        }
        else {
            return false
        }
    }
    return true
}
